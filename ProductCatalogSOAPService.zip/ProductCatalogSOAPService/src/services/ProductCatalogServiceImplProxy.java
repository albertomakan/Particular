package services;

public class ProductCatalogServiceImplProxy implements services.ProductCatalogServiceImpl {
  private String _endpoint = null;
  private services.ProductCatalogServiceImpl productCatalogServiceImpl = null;
  
  public ProductCatalogServiceImplProxy() {
    _initProductCatalogServiceImplProxy();
  }
  
  public ProductCatalogServiceImplProxy(String endpoint) {
    _endpoint = endpoint;
    _initProductCatalogServiceImplProxy();
  }
  
  private void _initProductCatalogServiceImplProxy() {
    try {
      productCatalogServiceImpl = (new services.ProductCatalogServiceImplServiceLocator()).getProductCatalogServiceImpl();
      if (productCatalogServiceImpl != null) {
        if (_endpoint != null)
          ((javax.xml.rpc.Stub)productCatalogServiceImpl)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
        else
          _endpoint = (String)((javax.xml.rpc.Stub)productCatalogServiceImpl)._getProperty("javax.xml.rpc.service.endpoint.address");
      }
      
    }
    catch (javax.xml.rpc.ServiceException serviceException) {}
  }
  
  public String getEndpoint() {
    return _endpoint;
  }
  
  public void setEndpoint(String endpoint) {
    _endpoint = endpoint;
    if (productCatalogServiceImpl != null)
      ((javax.xml.rpc.Stub)productCatalogServiceImpl)._setProperty("javax.xml.rpc.service.endpoint.address", _endpoint);
    
  }
  
  public services.ProductCatalogServiceImpl getProductCatalogServiceImpl() {
    if (productCatalogServiceImpl == null)
      _initProductCatalogServiceImplProxy();
    return productCatalogServiceImpl;
  }
  
  public services.Product searchById(int id) throws java.rmi.RemoteException{
    if (productCatalogServiceImpl == null)
      _initProductCatalogServiceImplProxy();
    return productCatalogServiceImpl.searchById(id);
  }
  
  public services.Product[] getAllProducts() throws java.rmi.RemoteException{
    if (productCatalogServiceImpl == null)
      _initProductCatalogServiceImplProxy();
    return productCatalogServiceImpl.getAllProducts();
  }
  
  public void insertProduct(services.Product product) throws java.rmi.RemoteException{
    if (productCatalogServiceImpl == null)
      _initProductCatalogServiceImplProxy();
    productCatalogServiceImpl.insertProduct(product);
  }
  
  
}