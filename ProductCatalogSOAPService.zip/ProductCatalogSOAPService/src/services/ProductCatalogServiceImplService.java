/**
 * ProductCatalogServiceImplService.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package services;

public interface ProductCatalogServiceImplService extends javax.xml.rpc.Service {
    public java.lang.String getProductCatalogServiceImplAddress();

    public services.ProductCatalogServiceImpl getProductCatalogServiceImpl() throws javax.xml.rpc.ServiceException;

    public services.ProductCatalogServiceImpl getProductCatalogServiceImpl(java.net.URL portAddress) throws javax.xml.rpc.ServiceException;
}
