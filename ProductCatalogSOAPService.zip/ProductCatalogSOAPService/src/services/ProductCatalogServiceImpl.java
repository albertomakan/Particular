/**
 * ProductCatalogServiceImpl.java
 *
 * This file was auto-generated from WSDL
 * by the Apache Axis 1.4 Apr 22, 2006 (06:55:48 PDT) WSDL2Java emitter.
 */

package services;

public interface ProductCatalogServiceImpl extends java.rmi.Remote {
    public services.Product searchById(int id) throws java.rmi.RemoteException;
    public services.Product[] getAllProducts() throws java.rmi.RemoteException;
    public void insertProduct(services.Product product) throws java.rmi.RemoteException;
}
